# var
Bin="IRModel/VSM/bin"
MainClass="test/demo/DemoIRSystem"

# execute
java -Xmx4G -Xms4G -cp $Bin $MainClass "$@"